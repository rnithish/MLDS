place the classifyDigits.py file in the same folder as the data files -
Seed.csv, Graph.csv and Extracted_features.csv

Ensure that SKLearn is installed
